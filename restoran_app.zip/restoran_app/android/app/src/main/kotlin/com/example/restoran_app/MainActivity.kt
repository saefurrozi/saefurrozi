package com.example.restoran_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
